/**
 * AuctionRoom.tsx — Verbal Auction, Host-Managed
 *
 * How it works:
 *  - Friends sit together (or on a call). The host runs this screen on a shared display.
 *  - Host picks the next player from the pool (or searches for one).
 *  - Everyone calls bids verbally. Host taps the bidding team + sets/raises the amount.
 *  - Host taps "Sold" to confirm, or "Unsold" to return to pool.
 *  - No timers. No auto-bids. Host is fully in control of pace.
 *  - Right panel = live log. Left panel = all team budgets + squads.
 */
import { useState, useRef, useMemo } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout/Layout";
import {
  ArrowLeft, Gavel, CheckCircle, XCircle, Crown,
  Search, ChevronRight, ChevronDown, RotateCcw,
  Plus, Minus, Users, Wallet, Trophy
} from "lucide-react";
import {
  IPL_2026_PLAYERS, TEAM_COLOR, TEAM_FULL_NAME,
  ROLE_LABEL, ROLE_ICON, ROLE_COLOR
} from "@/lib/ipl-constants";

// ── Types ──────────────────────────────────────────────────────────────────────
interface Player { name: string; team: string; role: string; credits: number; }
interface SquadEntry extends Player { price: number; }
interface Team  { id: string; name: string; color: string; budget: number; squad: SquadEntry[]; }
interface LogEntry {
  player: Player; status: "sold" | "unsold";
  winner?: string; winnerColor?: string; price?: number;
}

type Phase = "idle" | "nominated" | "sold" | "unsold";

// ── Constants ──────────────────────────────────────────────────────────────────
const ACCENT   = "#c0192c";
const BDR      = "rgba(255,255,255,0.08)";
const CARD     = "rgba(255,255,255,0.04)";
const DIM      = "rgba(255,255,255,0.35)";
const STARTING_BUDGET = 100; // crores

const INITIAL_TEAMS: Team[] = [
  { id: "t1", name: "Rajveer's Army",   color: "#c0392b", budget: STARTING_BUDGET, squad: [] },
  { id: "t2", name: "Karan's XI",       color: "#3b82f6", budget: STARTING_BUDGET, squad: [] },
  { id: "t3", name: "Arjun Plays",      color: "#a855f7", budget: STARTING_BUDGET, squad: [] },
  { id: "t4", name: "Sahil FC",         color: "#f59e0b", budget: STARTING_BUDGET, squad: [] },
];

function crFmt(n: number) {
  if (n === 0) return "₹0";
  return n % 1 === 0 ? `₹${n}Cr` : `₹${n.toFixed(1)}Cr`;
}

// ── Tiny reusable components ───────────────────────────────────────────────────

function BudgetBar({ team, compact = false }: { team: Team; compact?: boolean }) {
  const pct = Math.max(0, Math.round((team.budget / STARTING_BUDGET) * 100));
  const low = team.budget < 15;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: compact ? 3 : 5 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span style={{ fontSize: compact ? "0.72rem" : "0.82rem", fontWeight: 700, color: team.color, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 120 }}>
          {team.name}
        </span>
        <span style={{ fontSize: compact ? "0.7rem" : "0.78rem", fontFamily: "monospace", color: low ? "#f87171" : DIM, fontWeight: low ? 700 : 400 }}>
          {crFmt(team.budget)}
        </span>
      </div>
      <div style={{ height: compact ? 3 : 5, borderRadius: 3, background: "rgba(255,255,255,0.07)", overflow: "hidden" }}>
        <div style={{ height: "100%", borderRadius: 3, width: `${pct}%`, background: low ? "#ef4444" : team.color, transition: "width 0.4s ease" }} />
      </div>
      {!compact && (
        <span style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.25)" }}>{team.squad.length} players</span>
      )}
    </div>
  );
}

// ── Main ───────────────────────────────────────────────────────────────────────
export default function AuctionRoom() {
  const [, navigate]    = useLocation();

  // Team state
  const [teams, setTeams]       = useState<Team[]>(INITIAL_TEAMS);

  // Pool — unsold players go back in
  const soldIds                  = useRef<Set<string>>(new Set());
  const pool = useMemo(
    () => IPL_2026_PLAYERS.filter(p => !soldIds.current.has(p.name)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [teams]    // recalculate when teams change (squads update)
  );

  // Nomination state
  const [phase, setPhase]               = useState<Phase>("idle");
  const [nominated, setNominated]       = useState<Player | null>(null);
  const [currentBid, setCurrentBid]     = useState(0);
  const [leadTeamId, setLeadTeamId]     = useState<string | null>(null);
  const [log, setLog]                   = useState<LogEntry[]>([]);

  // Player search / browse panel
  const [search, setSearch]             = useState("");
  const [roleFilter, setRoleFilter]     = useState("ALL");
  const [poolOpen, setPoolOpen]         = useState(false);

  // Left panel tab
  const [leftTab, setLeftTab]           = useState<"budgets" | "squads">("budgets");
  const [expandedTeam, setExpandedTeam] = useState<string | null>(null);

  // Bid editing
  const [bidInput, setBidInput]         = useState("");
  const [bidFocused, setBidFocused]     = useState(false);

  const leadTeam = teams.find(t => t.id === leadTeamId) ?? null;

  // ── Actions ─────────────────────────────────────────────────────────────────

  function nominate(player: Player) {
    setNominated(player);
    setCurrentBid(parseFloat((player.credits * 0.8).toFixed(1)));
    setLeadTeamId(null);
    setPhase("nominated");
    setBidInput("");
    setPoolOpen(false);
    setSearch("");
  }

  function setBidForTeam(teamId: string, amount: number) {
    const team = teams.find(t => t.id === teamId)!;
    if (amount > team.budget) return; // can't bid more than they have
    setCurrentBid(amount);
    setLeadTeamId(teamId);
    setBidInput(String(amount));
  }

  function raiseBid(delta: number) {
    if (!leadTeamId) return;
    const newBid = parseFloat((currentBid + delta).toFixed(1));
    const team = teams.find(t => t.id === leadTeamId)!;
    if (newBid > team.budget) return;
    setCurrentBid(newBid);
    setBidInput(String(newBid));
  }

  function applyManualBid() {
    const val = parseFloat(bidInput);
    if (isNaN(val) || val <= 0 || !leadTeamId) return;
    const team = teams.find(t => t.id === leadTeamId)!;
    if (val > team.budget) return;
    setCurrentBid(val);
  }

  function confirmSold() {
    if (!nominated || !leadTeam) return;
    soldIds.current.add(nominated.name);
    setTeams(prev => prev.map(t =>
      t.id === leadTeamId
        ? { ...t, budget: parseFloat((t.budget - currentBid).toFixed(1)), squad: [...t.squad, { ...nominated, price: currentBid }] }
        : t
    ));
    setLog(prev => [{ player: nominated, status: "sold", winner: leadTeam.name, winnerColor: leadTeam.color, price: currentBid }, ...prev]);
    setPhase("sold");
  }

  function confirmUnsold() {
    if (!nominated) return;
    setLog(prev => [{ player: nominated, status: "unsold" }, ...prev]);
    setPhase("unsold");
  }

  function continueAfterResult() {
    setNominated(null);
    setLeadTeamId(null);
    setCurrentBid(0);
    setPhase("idle");
  }

  // ── Filtered pool ────────────────────────────────────────────────────────────
  const filteredPool = pool.filter(p => {
    const ms = roleFilter === "ALL" || p.role === roleFilter;
    const mq = p.name.toLowerCase().includes(search.toLowerCase()) || p.team.toLowerCase().includes(search.toLowerCase());
    return ms && mq;
  });

  const remainingCount = pool.length;

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <Layout>
      <div style={{ display: "flex", flexDirection: "column", gap: "1.25rem", height: "100%", minHeight: 0 }}>

        {/* ══ TOPBAR ══ */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.9rem" }}>
            <button
              onClick={() => navigate("/auction")}
              style={{ background: CARD, border: `1px solid ${BDR}`, borderRadius: 10, padding: "0.45rem 0.8rem", color: DIM, cursor: "pointer", display: "flex", alignItems: "center", gap: "0.35rem", fontSize: "0.8rem", fontWeight: 600 }}
            >
              <ArrowLeft style={{ width: 13, height: 13 }} /> Back
            </button>
            <div>
              <div style={{ fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: ACCENT }}>Host · Verbal Auction</div>
              <h1 style={{ margin: 0, fontSize: "1.55rem", fontWeight: 900, color: "#fff", letterSpacing: "-0.03em", lineHeight: 1 }}>Friday Night Draft</h1>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
            {/* Live badge */}
            <div style={{ padding: "0.35rem 0.85rem", background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 20, display: "flex", alignItems: "center", gap: "0.4rem" }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 6px #22c55e", animation: "livePulse 1.4s ease-in-out infinite" }} />
              <span style={{ fontSize: "0.68rem", fontWeight: 700, color: "#22c55e", letterSpacing: "0.08em" }}>LIVE</span>
            </div>
            <span style={{ fontSize: "0.78rem", color: DIM }}>{remainingCount} players left</span>
          </div>
        </div>

        {/* ══ MAIN 3-COL ══ */}
        <div style={{ display: "grid", gridTemplateColumns: "260px 1fr 280px", gap: "1rem", flex: 1, minHeight: 0, overflow: "hidden" }}>

          {/* ── LEFT: Teams ─────────────────────────────────────────────── */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem", overflowY: "auto", paddingRight: 2 }}>

            {/* Tab switcher */}
            <div style={{ display: "flex", gap: "0.4rem", flexShrink: 0 }}>
              {(["budgets", "squads"] as const).map(t => (
                <button key={t} onClick={() => setLeftTab(t)}
                  style={{ flex: 1, padding: "0.4rem", borderRadius: 8, border: `1px solid ${leftTab === t ? "rgba(255,255,255,0.15)" : BDR}`, background: leftTab === t ? "rgba(255,255,255,0.08)" : CARD, color: leftTab === t ? "#fff" : DIM, fontSize: "0.72rem", fontWeight: 600, cursor: "pointer", textTransform: "capitalize" }}>
                  {t}
                </button>
              ))}
            </div>

            {leftTab === "budgets" && teams.map(team => (
              <div key={team.id}
                style={{ background: leadTeamId === team.id ? `${team.color}12` : CARD, border: `1px solid ${leadTeamId === team.id ? `${team.color}40` : BDR}`, borderRadius: 12, padding: "0.85rem 1rem", transition: "all 0.2s", cursor: phase === "nominated" ? "pointer" : "default" }}
                onClick={() => { if (phase === "nominated") setBidForTeam(team.id, currentBid); }}
              >
                <BudgetBar team={team} />
                {/* Quick bid buttons — only when a player is nominated */}
                {phase === "nominated" && (
                  <div style={{ marginTop: "0.6rem", display: "flex", gap: "0.35rem" }}>
                    {[0.5, 1, 2, 5].map(inc => {
                      const newAmt = parseFloat((currentBid + inc).toFixed(1));
                      const canBid = team.budget >= newAmt;
                      return (
                        <button key={inc}
                          onClick={e => { e.stopPropagation(); if (canBid) setBidForTeam(team.id, newAmt); }}
                          style={{ flex: 1, padding: "0.3rem 0", borderRadius: 6, border: `1px solid ${canBid ? `${team.color}40` : BDR}`, background: canBid ? `${team.color}14` : "transparent", color: canBid ? team.color : "rgba(255,255,255,0.15)", fontSize: "0.65rem", fontWeight: 700, cursor: canBid ? "pointer" : "not-allowed" }}>
                          +{inc}
                        </button>
                      );
                    })}
                  </div>
                )}
                {leadTeamId === team.id && phase === "nominated" && (
                  <div style={{ marginTop: "0.5rem", fontSize: "0.7rem", color: team.color, fontWeight: 700, display: "flex", alignItems: "center", gap: "0.3rem" }}>
                    <Crown style={{ width: 11, height: 11 }} /> Leading at {crFmt(currentBid)}
                  </div>
                )}
              </div>
            ))}

            {leftTab === "squads" && teams.map(team => (
              <div key={team.id} style={{ background: CARD, border: `1px solid ${BDR}`, borderRadius: 12, overflow: "hidden" }}>
                {/* Squad header — click to expand */}
                <div
                  onClick={() => setExpandedTeam(expandedTeam === team.id ? null : team.id)}
                  style={{ padding: "0.75rem 1rem", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: expandedTeam === team.id ? `1px solid ${BDR}` : "none" }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: team.color }} />
                    <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#fff" }}>{team.name}</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
                    <span style={{ fontSize: "0.68rem", color: DIM }}>{team.squad.length}p · {crFmt(team.budget)}</span>
                    {expandedTeam === team.id ? <ChevronDown style={{ width: 12, height: 12, color: DIM }} /> : <ChevronRight style={{ width: 12, height: 12, color: DIM }} />}
                  </div>
                </div>
                {expandedTeam === team.id && (
                  <div style={{ padding: "0.5rem 0.75rem", display: "flex", flexDirection: "column", gap: "0.3rem", maxHeight: 200, overflowY: "auto" }}>
                    {team.squad.length === 0
                      ? <span style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.2)", fontStyle: "italic", padding: "0.25rem 0" }}>No players yet</span>
                      : team.squad.map((p, i) => (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: "0.5rem", padding: "0.3rem 0.5rem", borderRadius: 7, background: "rgba(255,255,255,0.03)" }}>
                          <span style={{ fontSize: "0.65rem", fontWeight: 700, color: TEAM_COLOR[p.team] ?? "#aaa", minWidth: 28 }}>{p.team}</span>
                          <span style={{ fontSize: "0.72rem", color: "#fff", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</span>
                          <span style={{ fontSize: "0.65rem", color: DIM, fontFamily: "monospace" }}>{crFmt(p.price)}</span>
                        </div>
                      ))
                    }
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* ── CENTRE: Stage ───────────────────────────────────────────── */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.9rem", overflow: "hidden" }}>

            {/* ── IDLE: Show player pool / search ── */}
            {phase === "idle" && (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "0.75rem", overflow: "hidden" }}>

                {/* Nominate prompt */}
                <div style={{ background: CARD, border: `1px solid ${BDR}`, borderRadius: 16, padding: "1.5rem", textAlign: "center", flexShrink: 0 }}>
                  <Gavel style={{ width: 36, height: 36, color: "rgba(255,255,255,0.15)", marginBottom: "0.75rem" }} />
                  <p style={{ margin: 0, fontSize: "1rem", fontWeight: 700, color: "rgba(255,255,255,0.5)" }}>Nominate the next player</p>
                  <p style={{ margin: "0.3rem 0 0", fontSize: "0.82rem", color: "rgba(255,255,255,0.25)" }}>Search or pick from the pool below — then call bids verbally</p>
                </div>

                {/* Search + filter */}
                <div style={{ display: "flex", gap: "0.5rem", flexShrink: 0 }}>
                  <div style={{ flex: 1, position: "relative" }}>
                    <Search style={{ position: "absolute", left: "0.85rem", top: "50%", transform: "translateY(-50%)", width: 14, height: 14, color: DIM, pointerEvents: "none" }} />
                    <input
                      value={search} onChange={e => setSearch(e.target.value)}
                      placeholder="Search players or teams…"
                      style={{ width: "100%", boxSizing: "border-box", padding: "0.6rem 0.9rem 0.6rem 2.3rem", background: CARD, border: `1px solid ${BDR}`, borderRadius: 10, color: "#fff", fontSize: "0.85rem", outline: "none" }}
                    />
                  </div>
                  {["ALL","BAT","BWL","AR","WK"].map(r => (
                    <button key={r} onClick={() => setRoleFilter(r)}
                      style={{ padding: "0.4rem 0.7rem", borderRadius: 9, border: `1px solid ${roleFilter === r ? "rgba(255,255,255,0.2)" : BDR}`, background: roleFilter === r ? "rgba(255,255,255,0.1)" : CARD, color: roleFilter === r ? "#fff" : DIM, fontSize: "0.72rem", fontWeight: 600, cursor: "pointer" }}>
                      {r}
                    </button>
                  ))}
                </div>

                {/* Player grid */}
                <div style={{ flex: 1, overflowY: "auto", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: "0.6rem", alignContent: "start" }}>
                  {filteredPool.map((player, i) => {
                    const tc = TEAM_COLOR[player.team] ?? "#aaa";
                    const rc = ROLE_COLOR[player.role] ?? "#aaa";
                    return (
                      <div key={i}
                        onClick={() => nominate(player)}
                        style={{ background: CARD, border: `1px solid ${BDR}`, borderRadius: 12, padding: "0.85rem", cursor: "pointer", transition: "all 0.15s", display: "flex", flexDirection: "column", gap: "0.4rem" }}
                        onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = `${tc}60`; (e.currentTarget as HTMLDivElement).style.background = `${tc}0a`; }}
                        onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = BDR; (e.currentTarget as HTMLDivElement).style.background = CARD; }}
                      >
                        {/* IPL team strip */}
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                          <span style={{ fontSize: "0.65rem", fontWeight: 800, color: tc, letterSpacing: "0.05em" }}>{player.team}</span>
                          <span style={{ fontSize: "0.62rem", color: rc, background: `${rc}18`, padding: "1px 6px", borderRadius: 4, fontWeight: 600 }}>{player.role}</span>
                        </div>
                        <div style={{ fontSize: "0.88rem", fontWeight: 700, color: "#fff", lineHeight: 1.25 }}>{player.name}</div>
                        <div style={{ fontSize: "0.7rem", color: DIM, fontFamily: "monospace" }}>{player.credits} cr</div>
                        <div style={{ marginTop: "0.2rem", fontSize: "0.68rem", color: ACCENT, fontWeight: 700, display: "flex", alignItems: "center", gap: "0.3rem" }}>
                          <Gavel style={{ width: 10, height: 10 }} /> Nominate
                        </div>
                      </div>
                    );
                  })}
                  {filteredPool.length === 0 && (
                    <div style={{ gridColumn: "1/-1", textAlign: "center", padding: "2rem", color: "rgba(255,255,255,0.2)", fontSize: "0.85rem" }}>
                      No players match your filter
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── NOMINATED: Player on stage ── */}
            {phase === "nominated" && nominated && (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "0.9rem", overflow: "hidden" }}>

                {/* Player card */}
                <div style={{ background: CARD, border: `1px solid ${leadTeam ? `${leadTeam.color}40` : BDR}`, borderRadius: 20, padding: "2rem 1.5rem", display: "flex", flexDirection: "column", alignItems: "center", position: "relative", overflow: "hidden", transition: "border-color 0.3s, box-shadow 0.3s", boxShadow: leadTeam ? `0 0 40px ${leadTeam.color}12` : "none", flexShrink: 0 }}>

                  {/* IPL team colour strip */}
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 4, background: TEAM_COLOR[nominated.team] ?? "#aaa", opacity: 0.8 }} />

                  {/* Team label */}
                  <div style={{ position: "absolute", top: 12, right: 14, fontSize: "0.65rem", fontWeight: 700, color: TEAM_COLOR[nominated.team] ?? "#aaa", background: `${TEAM_COLOR[nominated.team] ?? "#aaa"}18`, padding: "3px 10px", borderRadius: 20, letterSpacing: "0.08em" }}>
                    {nominated.team} · {TEAM_FULL_NAME[nominated.team]}
                  </div>

                  {/* Avatar circle */}
                  <div style={{ width: 72, height: 72, borderRadius: "50%", background: `${TEAM_COLOR[nominated.team] ?? "#aaa"}20`, border: `2px solid ${TEAM_COLOR[nominated.team] ?? "#aaa"}50`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.9rem", marginBottom: "0.9rem", marginTop: "0.5rem" }}>
                    {ROLE_ICON[nominated.role] ?? "🏏"}
                  </div>

                  <p style={{ margin: 0, fontSize: "1.75rem", fontWeight: 900, color: "#fff", letterSpacing: "-0.03em", textAlign: "center", lineHeight: 1.1 }}>{nominated.name}</p>
                  <p style={{ margin: "0.3rem 0 0", fontSize: "0.82rem", color: DIM }}>{ROLE_LABEL[nominated.role] ?? nominated.role} · Base {crFmt(parseFloat((nominated.credits * 0.8).toFixed(1)))}</p>
                </div>

                {/* ── BID CONTROL PANEL ── */}
                <div style={{ background: CARD, border: `1px solid ${BDR}`, borderRadius: 16, padding: "1.1rem 1.2rem", display: "flex", flexDirection: "column", gap: "0.85rem", flexShrink: 0 }}>

                  {/* Current bid + team selector */}
                  <div style={{ display: "flex", gap: "0.75rem", alignItems: "stretch" }}>

                    {/* Bid amount */}
                    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "0.4rem" }}>
                      <span style={{ fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.1em", color: DIM, textTransform: "uppercase" }}>Current Bid</span>
                      <div style={{ display: "flex", gap: "0.4rem", alignItems: "center" }}>
                        <button onClick={() => raiseBid(-0.5)} style={{ width: 32, height: 32, borderRadius: 8, background: "rgba(255,255,255,0.06)", border: `1px solid ${BDR}`, color: DIM, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <Minus style={{ width: 13, height: 13 }} />
                        </button>
                        <input
                          type="number" step="0.5" min="0"
                          value={bidFocused ? bidInput : currentBid}
                          onChange={e => setBidInput(e.target.value)}
                          onFocus={() => { setBidFocused(true); setBidInput(String(currentBid)); }}
                          onBlur={() => { setBidFocused(false); applyManualBid(); }}
                          onKeyDown={e => { if (e.key === "Enter") { (e.target as HTMLInputElement).blur(); } }}
                          style={{ flex: 1, padding: "0.4rem 0.6rem", background: "rgba(255,255,255,0.06)", border: `1.5px solid ${leadTeam ? `${leadTeam.color}50` : BDR}`, borderRadius: 9, color: leadTeam?.color ?? "#fff", fontSize: "1.5rem", fontWeight: 900, textAlign: "center", outline: "none", fontFamily: "monospace" }}
                        />
                        <button onClick={() => raiseBid(0.5)} style={{ width: 32, height: 32, borderRadius: 8, background: "rgba(255,255,255,0.06)", border: `1px solid ${BDR}`, color: DIM, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <Plus style={{ width: 13, height: 13 }} />
                        </button>
                      </div>
                      {/* Preset jumps */}
                      <div style={{ display: "flex", gap: "0.3rem" }}>
                        {[1, 2, 5, 10].map(inc => (
                          <button key={inc} onClick={() => raiseBid(inc)}
                            style={{ flex: 1, padding: "0.3rem 0", borderRadius: 6, border: `1px solid ${BDR}`, background: CARD, color: DIM, fontSize: "0.68rem", fontWeight: 700, cursor: "pointer" }}>
                            +{inc}Cr
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Bidding team selector */}
                    <div style={{ display: "flex", flexDirection: "column", gap: "0.4rem" }}>
                      <span style={{ fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.1em", color: DIM, textTransform: "uppercase" }}>Who bid?</span>
                      <div style={{ display: "flex", flexDirection: "column", gap: "0.3rem" }}>
                        {teams.map(team => {
                          const isLead = leadTeamId === team.id;
                          const canAfford = team.budget >= currentBid;
                          return (
                            <button key={team.id}
                              onClick={() => canAfford && setLeadTeamId(team.id)}
                              style={{ padding: "0.45rem 0.9rem", borderRadius: 9, border: `1.5px solid ${isLead ? team.color : canAfford ? BDR : "rgba(255,255,255,0.04)"}`, background: isLead ? `${team.color}20` : CARD, color: isLead ? team.color : canAfford ? "#fff" : "rgba(255,255,255,0.2)", fontWeight: isLead ? 800 : 500, fontSize: "0.78rem", cursor: canAfford ? "pointer" : "not-allowed", transition: "all 0.15s", display: "flex", alignItems: "center", gap: "0.4rem", whiteSpace: "nowrap" }}>
                              {isLead && <Crown style={{ width: 11, height: 11 }} />}
                              {team.name.split("'")[0]}
                              <span style={{ marginLeft: "auto", fontSize: "0.65rem", opacity: 0.6, fontFamily: "monospace" }}>{crFmt(team.budget)}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div style={{ display: "flex", gap: "0.6rem" }}>
                    <button
                      onClick={confirmSold}
                      disabled={!leadTeam}
                      style={{ flex: 1, padding: "0.85rem", borderRadius: 12, border: "none", background: leadTeam ? "#16a34a" : "rgba(22,163,74,0.15)", color: leadTeam ? "#fff" : "rgba(255,255,255,0.2)", fontWeight: 800, fontSize: "0.92rem", cursor: leadTeam ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem", transition: "all 0.15s" }}
                    >
                      <CheckCircle style={{ width: 17, height: 17 }} />
                      Sold to {leadTeam ? leadTeam.name.split("'")[0] : "…"} — {crFmt(currentBid)}
                    </button>
                    <button
                      onClick={confirmUnsold}
                      style={{ padding: "0.85rem 1.2rem", borderRadius: 12, border: `1px solid ${BDR}`, background: CARD, color: DIM, fontWeight: 700, fontSize: "0.88rem", cursor: "pointer", display: "flex", alignItems: "center", gap: "0.4rem" }}
                    >
                      <XCircle style={{ width: 15, height: 15 }} /> Unsold
                    </button>
                  </div>
                </div>

                {/* Hint */}
                <p style={{ margin: 0, fontSize: "0.72rem", color: "rgba(255,255,255,0.2)", textAlign: "center", flexShrink: 0 }}>
                  Call bids verbally → tap the team card on the left or "Who bid?" buttons → hit <b style={{ color: "rgba(255,255,255,0.35)" }}>Sold</b> when hammer drops
                </p>
              </div>
            )}

            {/* ── SOLD result ── */}
            {phase === "sold" && nominated && leadTeam && (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "0.75rem" }}>
                <CheckCircle style={{ width: 58, height: 58, color: "#22c55e" }} />
                <p style={{ margin: 0, fontSize: "2rem", fontWeight: 900, color: "#fff" }}>{nominated.name}</p>
                <p style={{ margin: 0, fontSize: "1.2rem", fontWeight: 700, color: leadTeam.color }}>{leadTeam.name}</p>
                <p style={{ margin: 0, fontSize: "2.5rem", fontWeight: 900, color: "#22c55e", fontFamily: "monospace" }}>{crFmt(currentBid)}</p>
                <div style={{ display: "flex", gap: "0.6rem", marginTop: "0.5rem" }}>
                  <button onClick={continueAfterResult}
                    style={{ padding: "0.85rem 2rem", background: ACCENT, border: "none", borderRadius: 12, color: "#fff", fontWeight: 800, fontSize: "0.92rem", cursor: "pointer", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                    Next Player <ChevronRight style={{ width: 16, height: 16 }} />
                  </button>
                </div>
              </div>
            )}

            {/* ── UNSOLD result ── */}
            {phase === "unsold" && nominated && (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "0.75rem" }}>
                <XCircle style={{ width: 58, height: 58, color: "#ef4444" }} />
                <p style={{ margin: 0, fontSize: "2rem", fontWeight: 900, color: "rgba(255,255,255,0.55)" }}>{nominated.name}</p>
                <p style={{ margin: "0.2rem 0 0", fontSize: "0.9rem", color: "rgba(255,255,255,0.3)" }}>Unsold — back to pool</p>
                <div style={{ display: "flex", gap: "0.6rem", marginTop: "0.5rem" }}>
                  <button onClick={continueAfterResult}
                    style={{ padding: "0.85rem 2rem", background: "rgba(255,255,255,0.07)", border: `1px solid ${BDR}`, borderRadius: 12, color: "#fff", fontWeight: 700, fontSize: "0.92rem", cursor: "pointer" }}>
                    Continue
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ── RIGHT: Auction log ──────────────────────────────────────── */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.7rem", overflowY: "auto" }}>

            {/* Mini budget summary */}
            <div style={{ background: CARD, border: `1px solid ${BDR}`, borderRadius: 12, padding: "0.85rem 1rem", flexShrink: 0 }}>
              <p style={{ margin: "0 0 0.7rem", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.12em", color: DIM, textTransform: "uppercase" }}>Budgets</p>
              <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem" }}>
                {teams.map(t => <BudgetBar key={t.id} team={t} compact />)}
              </div>
            </div>

            {/* Log header */}
            <p style={{ margin: 0, fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.12em", color: DIM, textTransform: "uppercase", flexShrink: 0 }}>
              Auction Log ({log.length})
            </p>

            {/* Log entries */}
            {log.length === 0
              ? <p style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.2)", fontStyle: "italic" }}>No sales yet</p>
              : log.map((entry, i) => (
                <div key={i} style={{ background: CARD, border: `1px solid ${entry.status === "sold" ? `${entry.winnerColor}25` : BDR}`, borderRadius: 10, padding: "0.65rem 0.85rem", flexShrink: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#fff" }}>{entry.player.name}</span>
                    {entry.status === "sold"
                      ? <span style={{ fontSize: "0.78rem", fontWeight: 800, color: "#22c55e", fontFamily: "monospace" }}>{crFmt(entry.price!)}</span>
                      : <span style={{ fontSize: "0.68rem", color: "#ef4444", fontWeight: 700 }}>UNSOLD</span>
                    }
                  </div>
                  {entry.status === "sold" && (
                    <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", marginTop: "0.2rem" }}>
                      <Crown style={{ width: 10, height: 10, color: entry.winnerColor }} />
                      <span style={{ fontSize: "0.7rem", color: entry.winnerColor, fontWeight: 600 }}>{entry.winner}</span>
                    </div>
                  )}
                  <div style={{ display: "flex", gap: "0.35rem", marginTop: "0.35rem" }}>
                    <span style={{ fontSize: "0.6rem", color: TEAM_COLOR[entry.player.team] ?? "#aaa", background: `${TEAM_COLOR[entry.player.team] ?? "#aaa"}18`, padding: "1px 5px", borderRadius: 4 }}>{entry.player.team}</span>
                    <span style={{ fontSize: "0.6rem", color: DIM, background: "rgba(255,255,255,0.06)", padding: "1px 5px", borderRadius: 4 }}>{ROLE_LABEL[entry.player.role]}</span>
                  </div>
                </div>
              ))
            }
          </div>
        </div>
      </div>

      <style>{`
        @keyframes livePulse { 0%,100%{opacity:1} 50%{opacity:0.35} }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }
      `}</style>
    </Layout>
  );
}
