import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { ArrowLeft, ChevronRight, Copy, Users } from "lucide-react";

const ACCENT    = "#c0192c";
const CARD      = "rgba(255,255,255,0.032)";
const BORDER    = "rgba(255,255,255,0.08)";
const LABEL_CLR = "rgba(255,255,255,0.35)";

function Label({ children }: { children: React.ReactNode }) {
  return (
    <span style={{ fontSize:"0.68rem", fontWeight:700, letterSpacing:"0.13em",
      textTransform:"uppercase", color:LABEL_CLR, display:"block", marginBottom:"0.75rem" }}>
      {children}
    </span>
  );
}

function Stepper({ value, onChange, min=1, max=99, suffix }:
  { value:number; onChange:(v:number)=>void; min?:number; max?:number; suffix?:string }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:"0.75rem" }}>
      <button type="button" onClick={()=>onChange(Math.max(min,value-1))}
        style={{ width:44, height:44, borderRadius:12, flexShrink:0,
          background:"rgba(255,255,255,0.07)", border:`1px solid ${BORDER}`,
          color:"rgba(255,255,255,0.65)", fontSize:"1.4rem",
          cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>−</button>
      <div style={{ flex:1, textAlign:"center" }}>
        <div style={{ fontSize:"2.2rem", fontWeight:900, color:"#fff", lineHeight:1 }}>{value}</div>
        {suffix&&<div style={{ fontSize:"0.7rem", color:LABEL_CLR, marginTop:"0.15rem" }}>{suffix}</div>}
      </div>
      <button type="button" onClick={()=>onChange(Math.min(max,value+1))}
        style={{ width:44, height:44, borderRadius:12, flexShrink:0,
          background:"rgba(255,255,255,0.07)", border:`1px solid ${BORDER}`,
          color:"rgba(255,255,255,0.65)", fontSize:"1.4rem",
          cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>+</button>
    </div>
  );
}

function Toggle({ on, onToggle }: { on:boolean; onToggle:()=>void }) {
  return (
    <div onClick={onToggle}
      style={{ width:52, height:28, borderRadius:14, flexShrink:0,
        background:on?ACCENT:"rgba(255,255,255,0.1)",
        border:`1.5px solid ${on?ACCENT:"rgba(255,255,255,0.12)"}`,
        cursor:"pointer", position:"relative", transition:"all 0.22s" }}>
      <div style={{ position:"absolute", top:3, left:on?26:3,
        width:18, height:18, borderRadius:"50%", background:"#fff",
        transition:"left 0.22s", boxShadow:"0 1px 4px rgba(0,0,0,0.4)" }} />
    </div>
  );
}

function genCode(name: string) {
  const prefix = name.replace(/[^a-zA-Z]/g,"").toUpperCase().slice(0,3)||"IPL";
  return `${prefix}${Math.random().toString(36).toUpperCase().slice(2,5)}`;
}

function Card({ children, style }: { children:React.ReactNode; style?:React.CSSProperties }) {
  return (
    <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:16,
      padding:"1.25rem 1.35rem", ...style }}>
      {children}
    </div>
  );
}

export default function CreateAuction() {
  const [, navigate] = useLocation();
  const [name, setName]             = useState("");
  const [nameFocused, setNameFocused] = useState(false);
  const [format, setFormat]         = useState<"classic"|"tier">("classic");
  const [maxPlayers, setMaxPlayers] = useState(11);
  const [budget, setBudget]         = useState(100);
  const [topScoring, setTopScoring] = useState(false);
  const [captainVC, setCaptainVC]   = useState(true);
  const [loading, setLoading]       = useState(false);
  const [code, setCode]             = useState("");
  const [copied, setCopied]         = useState(false);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setLoading(true);
    await new Promise(r=>setTimeout(r,600));
    setLoading(false);
    setCode(genCode(name));
  }

  function copyCode() {
    navigator.clipboard?.writeText(code);
    setCopied(true); setTimeout(()=>setCopied(false),1500);
  }

  // ── Invite code screen ──
  if (code) {
    return (
      <Layout>
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center",
          justifyContent:"center", minHeight:"60vh", gap:"1.25rem", textAlign:"center",
          padding:"1rem" }}>
          <div style={{ fontSize:"0.68rem", fontWeight:700, letterSpacing:"0.15em",
            color:ACCENT, textTransform:"uppercase" }}>Auction Created</div>
          <h1 style={{ margin:0, fontSize:"1.75rem", fontWeight:900, color:"#fff",
            letterSpacing:"-0.03em" }}>{name}</h1>
          <Card style={{ width:"100%", maxWidth:340, display:"flex", flexDirection:"column",
            alignItems:"center", gap:"0.85rem" }}>
            <p style={{ margin:0, fontSize:"0.68rem", fontWeight:700,
              letterSpacing:"0.12em", color:LABEL_CLR, textTransform:"uppercase" }}>
              Share to invite teams
            </p>
            <div style={{ fontSize:"2.8rem", fontWeight:900, color:"#fff",
              fontFamily:"monospace", letterSpacing:"0.3em" }}>{code}</div>
            <button onClick={copyCode}
              style={{ display:"flex", alignItems:"center", gap:"0.5rem",
                padding:"0.6rem 1.2rem", background:"rgba(255,255,255,0.07)",
                border:`1px solid ${BORDER}`, borderRadius:10,
                color:"#fff", fontSize:"0.82rem", fontWeight:600, cursor:"pointer" }}>
              <Copy style={{ width:13, height:13 }} />
              {copied?"Copied!":"Copy Code"}
            </button>
            <div style={{ fontSize:"0.75rem", color:LABEL_CLR }}>
              {maxPlayers} players · ₹{budget}Cr · {format==="classic"?"Classic":"Tier-Based"}
            </div>
          </Card>
          <div style={{ display:"flex", gap:"0.65rem", flexWrap:"wrap", justifyContent:"center" }}>
            <button onClick={()=>navigate("/auction/room")}
              style={{ padding:"0.85rem 1.75rem", background:ACCENT, border:"none",
                borderRadius:12, color:"#fff", fontWeight:800, fontSize:"0.9rem",
                cursor:"pointer", display:"flex", alignItems:"center", gap:"0.4rem" }}>
              <Users style={{ width:15, height:15 }} />
              Enter Auction Room
            </button>
            <button onClick={()=>navigate("/auction")}
              style={{ padding:"0.85rem 1.25rem", background:"rgba(255,255,255,0.06)",
                border:`1px solid ${BORDER}`, borderRadius:12,
                color:LABEL_CLR, fontWeight:600, fontSize:"0.85rem", cursor:"pointer" }}>
              Back
            </button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <form onSubmit={handleCreate} style={{ display:"flex", flexDirection:"column", gap:"1rem" }}>

        {/* Header */}
        <div style={{ display:"flex", alignItems:"center", gap:"0.85rem" }}>
          <button type="button" onClick={()=>navigate("/auction")}
            style={{ background:"rgba(255,255,255,0.06)", border:`1px solid ${BORDER}`,
              borderRadius:10, padding:"0.45rem 0.75rem", color:LABEL_CLR, cursor:"pointer",
              display:"flex", alignItems:"center", gap:"0.35rem", fontSize:"0.8rem", fontWeight:600 }}>
            <ArrowLeft style={{ width:14, height:14 }} /> Back
          </button>
          <div>
            <p style={{ margin:0, fontSize:"0.62rem", fontWeight:700,
              letterSpacing:"0.16em", textTransform:"uppercase", color:ACCENT }}>Auction</p>
            <h1 style={{ margin:0, fontSize:"1.55rem", fontWeight:900, color:"#fff",
              letterSpacing:"-0.03em", lineHeight:1 }}>Create New Auction</h1>
          </div>
        </div>

        {/* Form cards — single column on mobile, 2-col on md+ */}
        <div style={{ display:"grid",
          gridTemplateColumns:"1fr",
          gap:"0.85rem" }}
          className="md:grid-cols-2">

          {/* Name */}
          <Card>
            <Label>Auction Name</Label>
            <input type="text" value={name} onChange={e=>setName(e.target.value)}
              onFocus={()=>setNameFocused(true)} onBlur={()=>setNameFocused(false)}
              placeholder="e.g. Friday Night Draft"
              style={{ width:"100%", boxSizing:"border-box", padding:"0.85rem 1rem",
                background:nameFocused?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.04)",
                border:`1.5px solid ${nameFocused?"rgba(192,25,44,0.55)":"rgba(255,255,255,0.1)"}`,
                borderRadius:12, color:"#fff", fontSize:"1rem",
                outline:"none", transition:"all 0.18s" }} />
          </Card>

          {/* Format */}
          <Card style={{ display:"flex", flexDirection:"column", gap:"0.65rem" }}>
            <Label>Auction Format</Label>
            {(["classic","tier"] as const).map(f=>(
              <div key={f} onClick={()=>setFormat(f)}
                style={{ borderRadius:12, cursor:"pointer", padding:"0.9rem 1rem",
                  background:format===f?`${ACCENT}14`:"rgba(255,255,255,0.025)",
                  border:`1.5px solid ${format===f?`${ACCENT}55`:"rgba(255,255,255,0.07)"}`,
                  transition:"all 0.18s", display:"flex", alignItems:"center",
                  justifyContent:"space-between" }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:"0.95rem",
                    color:format===f?"#fff":"rgba(255,255,255,0.4)" }}>
                    {f==="classic"?"Classic":"Tier Based"}
                  </div>
                  <div style={{ fontSize:"0.75rem", color:"rgba(255,255,255,0.3)", marginTop:"0.2rem" }}>
                    {f==="classic"?"Open pool, highest bid wins":"Marquee → Core → Squad tiers"}
                  </div>
                </div>
                <div style={{ width:16, height:16, borderRadius:"50%", flexShrink:0,
                  background:format===f?ACCENT:"transparent",
                  border:`2px solid ${format===f?ACCENT:"rgba(255,255,255,0.2)"}`,
                  display:"flex", alignItems:"center", justifyContent:"center" }}>
                  {format===f&&<div style={{ width:5, height:5, borderRadius:"50%", background:"#fff" }} />}
                </div>
              </div>
            ))}
          </Card>

          {/* Squad size */}
          <Card>
            <Label>Max Players / Team</Label>
            <Stepper value={maxPlayers} onChange={setMaxPlayers} min={5} max={25} suffix="players per team" />
          </Card>

          {/* Budget */}
          <Card>
            <Label>Starting Budget</Label>
            <Stepper value={budget} onChange={setBudget} min={50} max={500} suffix="crores per team" />
          </Card>

          {/* Toggles */}
          <Card style={{ display:"flex", flexDirection:"column", gap:"0.75rem" }}>
            <Label>Options</Label>
            {[
              ["captainVC",   captainVC,   ()=>setCaptainVC(v=>!v),   "Captain & Vice-Captain", "2× and 1.5× multipliers"],
              ["topScoring",  topScoring,  ()=>setTopScoring(v=>!v),  "Top Scoring Only",       "Limit which players count"],
            ].map(([_k, val, fn, title, sub])=>(
              <div key={String(title)} style={{ display:"flex", alignItems:"center",
                justifyContent:"space-between", gap:"1rem" }}>
                <div>
                  <div style={{ fontSize:"0.88rem", fontWeight:600, color:"#fff" }}>{title as string}</div>
                  <div style={{ fontSize:"0.72rem", color:LABEL_CLR, marginTop:"0.1rem" }}>{sub as string}</div>
                </div>
                <Toggle on={val as boolean} onToggle={fn as ()=>void} />
              </div>
            ))}
          </Card>
        </div>

        {/* Footer */}
        <div style={{ display:"flex", justifyContent:"flex-end", gap:"0.6rem", paddingTop:"0.25rem" }}>
          <button type="button" onClick={()=>navigate("/auction")}
            style={{ padding:"0.75rem 1.25rem", background:"rgba(255,255,255,0.05)",
              border:`1px solid ${BORDER}`, borderRadius:11, color:LABEL_CLR,
              fontWeight:600, fontSize:"0.85rem", cursor:"pointer" }}>
            Cancel
          </button>
          <button type="submit" disabled={!name.trim()||loading}
            style={{ padding:"0.75rem 1.75rem",
              background:!name.trim()?"rgba(192,25,44,0.15)":ACCENT,
              border:"none", borderRadius:11,
              color:!name.trim()?"rgba(255,255,255,0.22)":"#fff",
              fontWeight:800, fontSize:"0.88rem",
              cursor:name.trim()&&!loading?"pointer":"default",
              display:"flex", alignItems:"center", gap:"0.4rem" }}>
            {loading?"Creating…":<><span>Create Auction</span><ChevronRight style={{ width:14, height:14 }} /></>}
          </button>
        </div>
      </form>
    </Layout>
  );
}
